2.0.1
 - Correção em regra geral do CSS

2.0.0
 - Refatoração da estrutura de diretórios do plugin
 - Atualização da versão do SDK PHP do PagSeguro
 - Criação e utilização de getters na classe WC_Order
 - Adição de testes antes do envio dos dados para o PagSeguro
 - Melhorias no lightbox
 - Correção na URL do PagSeguro e no formato dos headers

1.4.4
 - Correção de bugs no checkout transparente no redirecionamento e botões de pagamento de débito e boleto
 - Correção de bugs na url no checkout lightbox

1.4.0
 - Implementado checkout transparente (boleto, debito online e cartão de crédito)

1.3.0
 - Implementado conciliação e cancelamento

1.2.0
 - Implementado checkout com lightbox

1.1.1
 - Ajustes em geral

1.1.0
 - Ajuste na ativação/desativação do módulo

1.0.0
 - Versão inicial. Integração com API de checkout e API de notificações
