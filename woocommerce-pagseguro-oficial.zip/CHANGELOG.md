2.0.0
 - move files from woocommerce-pagseguro-oficial folder to root
 - update php-lib
 - access WC_Order properties by getters
 - change all file path's (create a constant relative to root plugin folder)
 - test data before send to pagseguro ws
 - improvements on lightbox checkout page
 - fix pagseguro url's
 - fix header bad format

1.4.4
 - Correção de bugs no checkout transparente no redirecionamento e botões de pagamento de débito e boleto.
 - Correção de bugs na url no checkout lightbox

1.4.0
 - Implementado checkout transparente (boleto, debito online e cartão de crédito)

1.3.0
 - Implementado conciliação e cancelamento.

1.2.0
 - Implementado checkout com lightbox.

1.1.1
 - Ajustes em geral

1.1.0
 - Ajuste na ativação/desativação do módulo.

1.0.0
 - Versão inicial. Integração com API de checkout e API de notificações.
